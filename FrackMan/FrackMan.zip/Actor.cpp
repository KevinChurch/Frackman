#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp




void Frackman::doSomething()
{
	if (this->isAlive() == false)
		return;

	//if (Frackman  is overlapping dirt)
	//		remove the dirt

	int ch;
	if (m_world->getKey(ch) == true)
	{
		// user hit a key this tick!
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			if (getX() == 0)
				break;
			moveTo(getX() - 1, getY());
			setDirection(left);
			if (m_world->deleteDirtRow(getX(), getY(), true))
				m_world->playSound(SOUND_DIG);
			break;
		case KEY_PRESS_RIGHT:
			if (getX() == 60)
				break;
			moveTo(getX() + 1, getY());
			setDirection(right);
			if (m_world->deleteDirtRow(getX() + 3, getY(), true))
				m_world->playSound(SOUND_DIG);
			break;
		case KEY_PRESS_UP:
			if (getY() == 60)
				break;
			moveTo(getX(), getY() + 1);
			setDirection(up);
			if (m_world->deleteDirtRow(getX(), getY() + 3, false))
				m_world->playSound(SOUND_DIG);
			break;
		case KEY_PRESS_DOWN:
			if (getY() == 0)
				break;
			moveTo(getX(), getY() - 1);
			setDirection(down);
			if (m_world->deleteDirtRow(getX(), getY(), false))
				m_world->playSound(SOUND_DIG);
		case KEY_PRESS_SPACE:
			//Add squirt in front of player
			;
			break;
			// etc�
		}
	}


}
