#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <vector>
#include <string>

using namespace std;

void updateDisplayText();
bool theplayerCompletedTheCurrentLevel();




class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
	 : GameWorld(assetDir)
	{
		for (size_t i = 0; i < 64; i++)
			for (size_t j = 0; j < 64; j++)
				dirt[j][i] = nullptr;
		player = nullptr;
	}

	~StudentWorld()
	{
		for (size_t i = 0; i < 64; i++)
			for (size_t j = 0; j < 64; j++)
				if (dirt[j][i] != nullptr)
				{
					delete dirt[j][i];
					dirt[j][i] = nullptr;
				}
		delete player;
		while (!actors.empty())
		{
			delete actors[0];
			actors[0] = actors[actors.size() - 1];
			actors.pop_back();
		}
	}
	void removeDeadGameObjects();
	virtual int init()
	{
		for (size_t i = 0; i < 64; i++)
			for (size_t j = 0; j < 64; j++)
				dirt[j][i] = nullptr;
		for (size_t i = 0; i < 4; i++)
			for (size_t j = 0; j < 64; j++)
				dirt[j][i] = new Dirt(j, i);
		for (size_t i = 4; i < 60; i++)
		{
			for (size_t j = 0; j < 30; j++)
				dirt[j][i] = new Dirt(j, i);
			for (size_t j = 34; j < 64; j++)
				dirt[j][i] = new Dirt(j, i);
		}

		player = new Frackman(this);

		return GWSTATUS_CONTINUE_GAME;
	}
	
	virtual int move()
	{
		  // Update the Game Status Line
		updateDisplayText(); // update the score/lives/level text at screen top
							 // The term �Actors� refers to all Protesters, the player, Goodies,
							 // Boulders, Barrels of oil, Holes, Squirts, the Exit, etc.
							 // Give each Actor a chance to do something
		//for each of the actors in the game world

		player->doSomething();
		for (size_t i = 0; i < actors.size(); i++)
		{
			if (actors[i]->isAlive()) //actor[i] is still active / alive
			{
				// ask each actor to do something (e.g. move)
				actors[i]->doSomething();
			/*	if (player->isAlive() == false)
				{
					playSound(SOUND_PLAYER_GIVE_UP);
					return GWSTATUS_PLAYER_DIED;
				}
				if (theplayerCompletedTheCurrentLevel() == true)
				{
					playSound(SOUND_FINISHED_LEVEL);
					return GWSTATUS_FINISHED_LEVEL;
				}
			*/}
		}
			// Remove newly-dead actors after each tick
	/*	removeDeadGameObjects(); // delete dead game objects
								 // return the proper result
		if (player->isAlive() == false)
		{
			playSound(SOUND_PLAYER_GIVE_UP);
			return GWSTATUS_PLAYER_DIED;
		}
		// If the player has collected all of the Barrels on the level, then
		// return the result that the player finished the level
		if (theplayerCompletedTheCurrentLevel() == true)
		{
			playSound(SOUND_FINISHED_LEVEL);
			return GWSTATUS_FINISHED_LEVEL;
		}
		// the player hasn�t completed the current level and hasn�t died
	*/	// let them continue playing the current level
		return GWSTATUS_CONTINUE_GAME;
	}
	
	virtual void cleanUp()
	{
		for (size_t i = 0; i < 64; i++)
			for (size_t j = 0; j < 64; j++)
				if (dirt[j][i] != nullptr)
				{
					delete dirt[j][i];
					dirt[j][i] = nullptr;
				}
		delete player;
		while (!actors.empty())
		{
			delete actors[0];
			actors[0] = actors[actors.size() - 1];
			actors.pop_back();
		}
	}
	bool deleteDirtRow(int x, int y, bool vertical);
private:
	vector<Actor*> actors;
	Frackman* player;
	Dirt* dirt[64][64];
};




#endif // STUDENTWORLD_H_
