#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
/*
Meant for:
The FrackMan
� Regular Protesters
� Hardcore Protesters
� Squirts of water (that can be shot by the FrackMan)
� Barrels of oil
� Boulders
� Gold Nuggets
� Sonar kits
� Water refills (that can be picked up to refill the FrackMan�s squirt gun)
� Dirt
*/

#define PLAYER_STARTX 30
#define PLAYER_STARTY 60

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, Direction dir, double size, unsigned int depth) :
		GraphObject(imageID, startX, startY, dir, size, depth)
	{
		setVisible(true);
	}
	virtual ~Actor() {}
	virtual bool isAlive() { return true; }
	virtual void doSomething() = 0;
private:

};

class ActiveObject : public Actor
{
public:
	ActiveObject(int imageID, int startX, int startY, Direction dir, unsigned int depth) :
		Actor(imageID, startX, startY, dir, 1, depth)
	{}
	~ActiveObject() {}
	void doSomething() { return; }
private:

};

class StaticObject : public Actor
{
public:
	StaticObject(int imageID, int startX, int startY, Direction dir, double size, unsigned int depth) :
		Actor(imageID, startX, startY, dir, size, depth)
	{}
	virtual ~StaticObject() {}
	void doSomething() { return; } //Stay still
private:

};

class Human : public ActiveObject
{
public:
	Human(int imageID, int startX, int startY, Direction dir, int health) :
		ActiveObject(imageID, startX, startY, dir, 0), m_hp(health)
	{}
	virtual ~Human() {}
private:
	int m_hp;
};

class Boulder : public ActiveObject
{
	Boulder(int imageID, int startX, int startY, Direction dir, int health) :
		ActiveObject(imageID, startX, startY, dir, 0)
	{}
	virtual ~Boulder() {}
public:

private:

};

class Frackman : public Human
{
public:
	Frackman(StudentWorld* w) :
		Human(IID_PLAYER, PLAYER_STARTX, PLAYER_STARTY, right, 10), m_world(w)
	{
		m_gold = 0;
		m_sonar = 1;
		m_squirt = 5;
	}
	virtual ~Frackman() 
	{
		m_world = nullptr;
	}
	void doSomething();
private:
	int m_gold;
	int m_sonar;
	int m_squirt;
	StudentWorld* m_world;
};

class Enemy: public Human
{
public:

private:

};

class RegProtest : public Enemy
{
public:

private:

};

class HardCoreProtest : public Enemy
{
public:

private:

};

class Dirt : public StaticObject
{
public:
	Dirt( int startX, int startY) :
		StaticObject(IID_DIRT, startX, startY, right, 0.25, 3)
	{}
	virtual ~Dirt() {}
private:

};

class Squirt : public StaticObject
{
public:

private:

};

class Pickup : public StaticObject
{
public:

private:

};

class Gold : public Pickup
{
public:

private:
};

class Sonar : public Pickup
{
public:

private:
};

class WaterRefill : public Pickup
{
public:

private:
};
#endif // ACTOR_H_
