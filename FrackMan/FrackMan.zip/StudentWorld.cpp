#include "StudentWorld.h"
#include <string>
using namespace std;

Actor;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

void StudentWorld::removeDeadGameObjects()
{
	for (size_t i = 0; i < actors.size(); i++)
	{
		if (!actors[i]->isAlive())
		{
			delete actors[i];
			i--;
		}
	}
}

bool StudentWorld::deleteDirtRow(int x, int y, bool vertical)
{
	bool dugDirt = false;

	if (vertical)
	{
		for (int i = y; i < y + 4; i++)
		{
			if (dirt[x][i])
			{
				dugDirt = true;
				delete dirt[x][i];
				dirt[x][i] = nullptr;
			}
		}
	}
	else
	{
		for (int i = x; i < x + 4; i++)
		{
			if (dirt[i][y])
			{
				dugDirt = true;
				delete dirt[i][y];
				dirt[i][y] = nullptr;
			}
		}
	}

	return dugDirt;
}

void updateDisplayText() {}
bool theplayerCompletedTheCurrentLevel() { return false; }